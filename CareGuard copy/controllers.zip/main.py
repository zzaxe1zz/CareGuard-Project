import customtkinter as ctk
from tkinter import messagebox
from controllers.auth_controller import AuthController
from views.components.medical_view import MedicalView
from views.components.psychology_view import PsychologyView
from views.components.admin_dashboard import AdminDashboardView
from views.components.kiosk_view import KioskView

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")


class LoginWindow(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("CareGuard - Autenticación Seguro")
        self.geometry("420x580")
        self.resizable(False, False)

        self.auth_controller = AuthController()

        # Contenedor principal
        self.frame = ctk.CTkFrame(self, corner_radius=15)
        self.frame.pack(padx=20, pady=20, fill="both", expand=True)

        # Encabezado
        self.lbl_title = ctk.CTkLabel(
            self.frame, text="CareGuard", font=ctk.CTkFont(size=28, weight="bold")
        )
        self.lbl_title.pack(pady=(30, 5))

        self.lbl_subtitle = ctk.CTkLabel(
            self.frame, text="Sistema de Prevención de Burnout", font=ctk.CTkFont(size=12)
        )
        self.lbl_subtitle.pack(pady=(0, 25))

        # Campos de formulario
        self.entry_usuario = ctk.CTkEntry(
            self.frame, placeholder_text="Nombre de usuario", width=300, height=40
        )
        self.entry_usuario.pack(pady=10)

        self.entry_password = ctk.CTkEntry(
            self.frame, placeholder_text="Contraseña", show="*", width=300, height=40
        )
        self.entry_password.pack(pady=10)

        self.lbl_rol = ctk.CTkLabel(
            self.frame, text="Rol de acceso asignado:", anchor="w")
        self.lbl_rol.pack(padx=40, anchor="w", pady=(10, 0))

        self.combo_rol = ctk.CTkOptionMenu(
            self.frame,
            values=["MEDICO", "ENFERMERO", "PSICOLOGO",
                    "ADMIN", "PACIENTE (Kiosco)"],
            width=300,
            height=35
        )
        self.combo_rol.pack(pady=5)
        self.combo_rol.set("MEDICO")

        # Botón de ingreso
        self.btn_login = ctk.CTkButton(
            self.frame, text="Iniciar Sesión", width=300, height=45, command=self.procesar_login
        )
        self.btn_login.pack(pady=30)

    def procesar_login(self):
        usuario = self.entry_usuario.get().strip()
        password = self.entry_password.get()
        rol = self.combo_rol.get()

        # Acceso directo al modo Kiosco sin autenticación explícita
        if rol == "PACIENTE (Kiosco)":
            self.withdraw()
            KioskView(self)
            return

        session = self.auth_controller.login(usuario, password, rol)

        if not session:
            messagebox.showerror("Error de Autenticación",
                                 "Credenciales inválidas o rol no asignado.")
            return

        self.withdraw()

        # Enrutamiento basado en RBAC (RF-15)
        if session.rol in ["MEDICO", "ENFERMERO"]:
            MedicalView(self, session)
        elif session.rol == "PSICOLOGO":
            PsychologyView(self, session)
        elif session.rol == "ADMIN":
            AdminDashboardView(self, session)


if __name__ == "__main__":
    app = LoginWindow()
    app.mainloop()
