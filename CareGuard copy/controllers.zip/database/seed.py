from database.db_adapter import DatabaseAdapter
from utils.security import generar_salt, hash_password


def sembrar_datos_iniciales(db_path: str = "careguard.db") -> None:
    """Inserta cuentas base con credenciales cifradas si la BD está vacía."""
    db = DatabaseAdapter(db_path)

    # Verificar si ya existen usuarios
    usuarios_existentes = db.obtener_todos("SELECT id_usuario FROM usuarios")
    if usuarios_existentes:
        print("La base de datos ya contiene usuarios. Omitiendo sembrado.")
        return

    # Usuarios de prueba base
    cuentas_demo = [
        ("Administrador General", "admin", "admin123", "ADMIN"),
        ("Dr. Carlos Gomez", "medico1", "medico123", "MEDICO"),
        ("Dra. Sofia Lopez", "psico1", "psico123", "PSICOLOGO"),
        ("Enf. Maria Torres", "enfermera1", "enf123", "ENFERMERO"),
    ]

    query = """
        INSERT INTO usuarios (nombre, usuario, hash_password, salt, rol, estado)
        VALUES (?, ?, ?, ?, ?, 'ACTIVO')
    """

    for nombre, usuario, pwd, rol in cuentas_demo:
        salt = generar_salt()
        pwd_hash = hash_password(pwd, salt)
        db.ejecutar(query, (nombre, usuario, pwd_hash, salt, rol))
        print(f"Usuario registrado -> [{rol}] {usuario}")

    print("Sembrado de datos iniciales completado exitosamente.")


if __name__ == "__main__":
    sembrar_datos_iniciales()
