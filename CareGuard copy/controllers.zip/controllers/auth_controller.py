from typing import Optional, List
from database.db_adapter import DatabaseAdapter
from database.audit_logger import AuditLogger
from models.dto import SessionDTO
from utils.security import verificar_password, sanitizar_texto


class AuthController:
    def __init__(self, db: Optional[DatabaseAdapter] = None, audit: Optional[AuditLogger] = None):
        self.db = db or DatabaseAdapter()
        self.audit = audit or AuditLogger()

    def login(self, usuario_raw: str, password_raw: str, rol_esperado: str) -> Optional[SessionDTO]:
        """
        Valida las credenciales contra la BD mediante hashing e impone aislamiento por rol (RF-12, RF-15).
        """
        usuario = sanitizar_texto(usuario_raw)
        rol_esperado = sanitizar_texto(rol_esperado).upper()

        query = """
            SELECT id_usuario, nombre, usuario, hash_password, salt, rol, estado
            FROM usuarios
            WHERE usuario = ? AND estado = 'ACTIVO'
        """
        usuario_db = self.db.obtener_uno(query, (usuario,))

        if not usuario_db:
            self.audit.registrar_evento(
                None, rol_esperado, "LOGIN", False, f"Usuario no encontrado o inactivo: {usuario}")
            return None

        # Validación del hash seguro (PBKDF2)
        if not verificar_password(password_raw, usuario_db["hash_password"], usuario_db["salt"]):
            self.audit.registrar_evento(
                usuario_db["id_usuario"], rol_esperado, "LOGIN", False, "Contraseña incorrecta")
            return None

        # Verificación de concordancia de rol (RBAC)
        rol_real = usuario_db["rol"].upper()
        if rol_real != rol_esperado:
            self.audit.registrar_evento(
                usuario_db["id_usuario"], rol_esperado, "LOGIN", False,
                f"Discrepancia de rol solicitada ({rol_esperado}) vs asignada ({rol_real})"
            )
            return None

        self.audit.registrar_evento(
            usuario_db["id_usuario"], rol_real, "LOGIN", True, "Autenticación exitosa")

        return SessionDTO(
            id_usuario=usuario_db["id_usuario"],
            nombre=usuario_db["nombre"],
            usuario=usuario_db["usuario"],
            rol=rol_real
        )

    def validar_acceso_modulo(self, session: Optional[SessionDTO], roles_permitidos: List[str]) -> bool:
        """
        Middleware programmatic de seguridad RBAC para autorizar acceso a vistas y métodos (RF-15).
        """
        roles_permitidos_upper = [r.upper() for r in roles_permitidos]

        if not session:
            self.audit.registrar_evento(
                None, "DESCONOCIDO", "ACCESO_MODULO", False, "Intento de acceso sin sesión activa")
            return False

        if session.rol.upper() not in roles_permitidos_upper:
            self.audit.registrar_evento(
                session.id_usuario, session.rol, "ACCESO_MODULO", False,
                f"Acceso no autorizado intentado a módulo restringido para {roles_permitidos_upper}"
            )
            return False

        return True
