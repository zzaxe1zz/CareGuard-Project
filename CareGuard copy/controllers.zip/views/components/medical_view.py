import customtkinter as ctk
from tkinter import messagebox, ttk
from controllers.medical_controller import MedicalController
from models.dto import SessionDTO


class MedicalView(ctk.CTkToplevel):
    def __init__(self, parent, session: SessionDTO):
        super().__init__(parent)
        self.parent = parent
        self.session = session
        self.controller = MedicalController(session)

        self.id_jornada_activa = None

        self.title(f"CareGuard - Panel Médico | {session.nombre}")
        self.geometry("850x650")
        self.protocol("WM_DELETE_WINDOW", self.cerrar_aplicacion)

        self._crear_interfaz()

    def _crear_interfaz(self):
        # Header
        self.lbl_welcome = ctk.CTkLabel(
            self, text=f"Bienvenido(a), {self.session.nombre}", font=ctk.CTkFont(size=20, weight="bold")
        )
        self.lbl_welcome.pack(pady=15)

        # Tabview
        self.tabs = ctk.CTkTabview(self, width=800, height=520)
        self.tabs.pack(padx=20, pady=10, fill="both", expand=True)

        self.tab_jornada = self.tabs.add("Turno Activo y Evaluación")
        self.tab_historial = self.tabs.add("Mi Historial Semanal")

        self._configurar_tab_jornada()
        self._configurar_tab_historial()

    def _configurar_tab_jornada(self):
        # Sección de Control de Jornada
        frame_turno = ctk.CTkFrame(self.tab_jornada)
        frame_turno.pack(fill="x", padx=15, pady=10)

        ctk.CTkLabel(frame_turno, text="Control de Jornada Laboral",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(pady=5)

        self.btn_entrada = ctk.CTkButton(
            frame_turno, text="Registrar Entrada (Check-In)", command=self._registrar_entrada)
        self.btn_entrada.pack(side="left", padx=20, pady=15)

        self.btn_descanso = ctk.CTkButton(
            frame_turno, text="Registrar Descanso", command=self._solicitar_descanso, state="disabled")
        self.btn_descanso.pack(side="left", padx=10, pady=15)

        # Sección de Evaluacion Emocional
        frame_emo = ctk.CTkFrame(self.tab_jornada)
        frame_emo.pack(fill="both", expand=True, padx=15, pady=10)

        ctk.CTkLabel(frame_emo, text="Evaluación de Cierre de Turno",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(pady=5)

        ctk.CTkLabel(
            frame_emo, text="Nivel de Estrés Percibido (1 al 10):").pack(pady=2)
        self.slider_estres = ctk.CTkSlider(
            frame_emo, from_=1, to=10, number_of_steps=9)
        self.slider_estres.pack(pady=5, fill="x", padx=40)

        ctk.CTkLabel(
            frame_emo, text="Estado de Ánimo Predominante:").pack(pady=2)
        self.combo_animo = ctk.CTkOptionMenu(
            frame_emo, values=["Excelente", "Estable", "Agotado", "Muy Estresado"])
        self.combo_animo.pack(pady=5)

        self.txt_notas = ctk.CTkTextbox(frame_emo, height=60, width=400)
        self.txt_notas.pack(pady=5)

        self.btn_salida = ctk.CTkButton(
            frame_emo, text="Cerrar Turno y Guardar Evaluación", fg_color="green",
            command=self._registrar_salida, state="disabled"
        )
        self.btn_salida.pack(pady=10)

        # Botón voluntario de apoyo
        self.btn_apoyo = ctk.CTkButton(
            self.tab_jornada, text="Solicitar Apoyo Psicológico Directo", fg_color="#D9534F",
            command=self._solicitar_apoyo
        )
        self.btn_apoyo.pack(pady=10)

    def _configurar_tab_historial(self):
        self.btn_cargar_historial = ctk.CTkButton(
            self.tab_historial, text="Actualizar Historial", command=self._cargar_historial)
        self.btn_cargar_historial.pack(pady=10)

        self.tree_historial = ttk.Treeview(
            self.tab_historial, columns=("Fecha", "Entrada", "Salida", "Horas Trab", "Horas Extra"), show="headings"
        )
        for col in ("Fecha", "Entrada", "Salida", "Horas Trab", "Horas Extra"):
            self.tree_historial.heading(col, text=col)
            self.tree_historial.column(col, width=130, anchor="center")

        self.tree_historial.pack(fill="both", expand=True, padx=10, pady=10)

    def _registrar_entrada(self):
        self.id_jornada_activa = self.controller.iniciar_jornada()
        messagebox.showinfo(
            "Check-In Exitoso", f"Entrada registrada para la jornada ID #{self.id_jornada_activa}")
        self.btn_entrada.configure(state="disabled")
        self.btn_descanso.configure(state="normal")
        self.btn_salida.configure(state="normal")

    def _solicitar_descanso(self):
        dialog_inicio = ctk.CTkInputDialog(
            text="Hora inicio (YYYY-MM-DD HH:MM:SS):", title="Registro Descanso")
        h_inicio = dialog_inicio.get_input()
        dialog_fin = ctk.CTkInputDialog(
            text="Hora fin (YYYY-MM-DD HH:MM:SS):", title="Registro Descanso")
        h_fin = dialog_fin.get_input()

        if h_inicio and h_fin:
            try:
                self.controller.registrar_descanso(
                    self.id_jornada_activa, h_inicio, h_fin)
                messagebox.showinfo("Éxito", "Periodo de descanso almacenado.")
            except Exception as e:
                messagebox.showerror("Error de Validación", str(e))

    def _registrar_salida(self):
        if not self.id_jornada_activa:
            return

        estres = int(self.slider_estres.get())
        animo = self.combo_animo.get()
        notas = self.txt_notas.get("1.0", "end-1c")

        try:
            res = self.controller.finalizar_jornada_y_evaluar(
                self.id_jornada_activa, estres, animo, notas)
            msg = f"Jornada finalizada.\nHoras Trabajadas: {res['resumen_jornada']['horas_trabajadas']}\nHoras Extra: {res['resumen_jornada']['horas_extra']}"
            if res['alerta_generada']:
                msg += "\n\nSe ha generado una alerta automática de sobrecarga preventiva para Psicología."
            messagebox.showinfo("Registro Exitoso", msg)

            self.id_jornada_activa = None
            self.btn_entrada.configure(state="normal")
            self.btn_descanso.configure(state="disabled")
            self.btn_salida.configure(state="disabled")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _solicitar_apoyo(self):
        self.controller.solicitar_apoyo_psicologico(
            "Solicitado desde panel médico")
        messagebox.showinfo(
            "Solicitud Recibida", "El departamento de Psicología ha sido notificado de manera confidencial.")

    def _cargar_historial(self):
        for item in self.tree_historial.get_children():
            self.tree_historial.delete(item)

        historial = self.controller.consultar_historial_propio()
        for fila in historial:
            self.tree_historial.insert("", "end", values=(
                fila["fecha"], fila["hora_entrada"], fila["hora_salida"] or "En curso",
                fila["horas_trabajadas"], fila["horas_extra"]
            ))

    def cerrar_aplicacion(self):
        self.parent.destroy()
