import customtkinter as ctk
from tkinter import messagebox, ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from controllers.admin_controller import AdminController
from models.dto import SessionDTO


class AdminDashboardView(ctk.CTkToplevel):
    def __init__(self, parent, session: SessionDTO):
        super().__init__(parent)
        self.parent = parent
        self.session = session
        self.controller = AdminController(session)

        self.title("CareGuard - Dashboard Administrativo Global")
        self.geometry("950x700")
        self.protocol("WM_DELETE_WINDOW", self.cerrar_aplicacion)

        self._crear_interfaz()

    def _crear_interfaz(self):
        self.tabs = ctk.CTkTabview(self)
        self.tabs.pack(fill="both", expand=True, padx=15, pady=15)

        self.tab_metrics = self.tabs.add("Métricas e Indicadores (RF-11)")
        self.tab_users = self.tabs.add("Gestión de Usuarios (RF-12)")

        self._configurar_tab_metrics()
        self._configurar_tab_users()

    def _configurar_tab_metrics(self):
        metricas = self.controller.obtener_metricas_dashboard()

        # Resumen superior
        lbl_sat = ctk.CTkLabel(
            self.tab_metrics,
            text=f"Satisfacción General Pacientes: {metricas['promedio_satisfaccion']} / 5.0  ({metricas['total_evaluaciones']} evaluaciones)",
            font=ctk.CTkFont(size=14, weight="bold")
        )
        lbl_sat.pack(pady=10)

        # Gráfico Matplotlib
        fig, ax = plt.subplots(figsize=(6, 3.5), dpi=100)

        roles = [item["rol"] for item in metricas["horas_extra_agregadas"]]
        horas = [item["total_horas_extra"]
                 for item in metricas["horas_extra_agregadas"]]

        if not roles:
            roles = ["Sin datos"]
            horas = [0]

        ax.bar(roles, horas, color="#4A90E2")
        ax.set_title("Horas Extra Acumuladas por Rol (Últimos 30 días)")
        ax.set_ylabel("Horas Totales")

        canvas = FigureCanvasTkAgg(fig, master=self.tab_metrics)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)

    def _configurar_tab_users(self):
        frame_form = ctk.CTkFrame(self.tab_users)
        frame_form.pack(padx=20, pady=20, fill="both", expand=True)

        ctk.CTkLabel(frame_form, text="Alta de Nuevos Usuarios",
                     font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)

        self.entry_nom = ctk.CTkEntry(
            frame_form, placeholder_text="Nombre Completo", width=300)
        self.entry_nom.pack(pady=8)

        self.entry_usr = ctk.CTkEntry(
            frame_form, placeholder_text="Nombre de Usuario", width=300)
        self.entry_usr.pack(pady=8)

        self.entry_pwd = ctk.CTkEntry(
            frame_form, placeholder_text="Contraseña", show="*", width=300)
        self.entry_pwd.pack(pady=8)

        self.combo_rol_nuevo = ctk.CTkOptionMenu(
            frame_form, values=["MEDICO", "ENFERMERO", "PSICOLOGO", "ADMIN"], width=300)
        self.combo_rol_nuevo.pack(pady=8)

        ctk.CTkButton(frame_form, text="Registrar Cuenta",
                      command=self._registrar_usuario).pack(pady=20)

    def _registrar_usuario(self):
        try:
            self.controller.registrar_usuario(
                self.entry_nom.get(), self.entry_usr.get(
                ), self.entry_pwd.get(), self.combo_rol_nuevo.get()
            )
            messagebox.showinfo(
                "Éxito", "Cuenta creada exitosamente con credenciales cifradas PBKDF2.")
            self.entry_nom.delete(0, "end")
            self.entry_usr.delete(0, "end")
            self.entry_pwd.delete(0, "end")
        except Exception as e:
            messagebox.showerror("Error de Creación", str(e))

    def cerrar_aplicacion(self):
        self.parent.destroy()
