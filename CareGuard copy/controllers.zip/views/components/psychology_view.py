import customtkinter as ctk
from tkinter import messagebox, ttk
from controllers.psychology_controller import PsychologyController
from models.dto import SessionDTO


class PsychologyView(ctk.CTkToplevel):
    def __init__(self, parent, session: SessionDTO):
        super().__init__(parent)
        self.parent = parent
        self.session = session
        self.controller = PsychologyController(session)

        self.title("CareGuard - Módulo de Salud Mental y Psicología")
        self.geometry("900x600")
        self.protocol("WM_DELETE_WINDOW", self.cerrar_aplicacion)

        self._crear_interfaz()

    def _crear_interfaz(self):
        ctk.CTkLabel(self, text="Bandeja de Control de Alertas de Sobrecarga",
                     font=ctk.CTkFont(size=20, weight="bold")).pack(pady=15)

        # Tabla de Alertas
        self.tree_alertas = ttk.Treeview(
            self, columns=("ID", "Profesional", "Fecha", "Tipo", "Estado", "Motivo"), show="headings"
        )
        col_widths = {"ID": 40, "Profesional": 150, "Fecha": 130,
                      "Tipo": 90, "Estado": 90, "Motivo": 300}
        for col, width in col_widths.items():
            self.tree_alertas.heading(col, text=col)
            self.tree_alertas.column(col, width=width, anchor="w")

        self.tree_alertas.pack(fill="both", expand=True, padx=20, pady=10)

        # Panel de Acciones
        frame_acciones = ctk.CTkFrame(self)
        frame_acciones.pack(fill="x", padx=20, pady=10)

        ctk.CTkButton(frame_acciones, text="Refrescar Bandeja",
                      command=self._cargar_alertas).pack(side="left", padx=10, pady=10)
        ctk.CTkButton(frame_acciones, text="Ver Expediente Confidencial",
                      command=self._ver_expediente).pack(side="left", padx=10, pady=10)

        self.combo_estado = ctk.CTkOptionMenu(
            frame_acciones, values=["EN_ATENCION", "CERRADA"])
        self.combo_estado.pack(side="left", padx=10, pady=10)

        ctk.CTkButton(frame_acciones, text="Cambiar Estado / Guardar Nota",
                      command=self._actualizar_alerta).pack(side="left", padx=10, pady=10)

        self._cargar_alertas()

    def _cargar_alertas(self):
        for item in self.tree_alertas.get_children():
            self.tree_alertas.delete(item)

        alertas = self.controller.consultar_bandeja_alertas()
        for a in alertas:
            self.tree_alertas.insert("", "end", values=(
                a.id_alerta, a.nombre_profesional, a.fecha_generacion, a.tipo, a.estado, a.motivo
            ))

    def _actualizar_alerta(self):
        seleccion = self.tree_alertas.selection()
        if not seleccion:
            messagebox.showwarning(
                "Atención", "Seleccione una alerta de la lista.")
            return

        item = self.tree_alertas.item(seleccion[0])
        id_alerta = item["values"][0]
        nuevo_estado = self.combo_estado.get()

        dialog_nota = ctk.CTkInputDialog(
            text="Observaciones de seguimiento:", title="Bitácora de Psicología")
        nota = dialog_nota.get_input() or ""

        self.controller.actualizar_estado_alerta(id_alerta, nuevo_estado, nota)
        messagebox.showinfo("Éxito", "Alerta actualizada correctamente.")
        self._cargar_alertas()

    def _ver_expediente(self):
        seleccion = self.tree_alertas.selection()
        if not seleccion:
            messagebox.showwarning(
                "Atención", "Seleccione una alerta para consultar al profesional.")
            return

        item = self.tree_alertas.item(seleccion[0])
        # En la práctica se obtiene id_usuario
        id_alerta = item["values"][0]
        alertas = self.controller.consultar_bandeja_alertas()
        alerta_obj = next(
            (a for a in alertas if a.id_alerta == id_alerta), None)

        if alerta_obj:
            expediente = self.controller.consultar_expediente_confidencial(
                alerta_obj.id_usuario)
            msg = f"EXPEDIENTE CONFIDENCIAL: {expediente['medico']['nombre']}\n\n"
            msg += f"Registros Emocionales Totales: {len(expediente['historial_emocional'])}\n"
            msg += f"Jornadas Registradas Totales: {len(expediente['historial_jornadas'])}"
            messagebox.showinfo("Expediente Sanitario", msg)

    def cerrar_aplicacion(self):
        self.parent.destroy()
